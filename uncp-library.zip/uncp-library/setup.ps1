Set-Location $PSScriptRoot
$php='C:\xampp\php\php.exe'
if(-not (Test-Path $php)){ $cmd=Get-Command php -ErrorAction SilentlyContinue; if($cmd){$php=$cmd.Source} }
if(-not (Test-Path $php)){ Write-Host 'PHP tidak ditemukan. Pastikan XAMPP terpasang atau PHP masuk PATH.'; exit 1 }
if (-not (Test-Path .env)) { Copy-Item .env.example .env }
$mysql='C:\xampp\mysql\bin\mysql.exe'
if(Test-Path $mysql){
  & $mysql -u root -e "CREATE DATABASE IF NOT EXISTS uncp_library CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;"
  Get-Content database/database.sql | & $mysql -u root uncp_library
  Get-Content database/migrate_requirements.sql | & $mysql -u root uncp_library
} else { Write-Host 'mysql.exe tidak ditemukan; import database/database.sql lalu database/migrate_requirements.sql melalui phpMyAdmin.' }
& $php tools/seed.php
& $php tools/check-system.php
