Set-Location $PSScriptRoot
php -S localhost:8000
