@echo off
setlocal EnableExtensions
cd /d %~dp0

echo ========================================
echo UNCP LIBRARY - SETUP
echo ========================================

set "PHP_EXE="
if exist "C:\xampp\php\php.exe" set "PHP_EXE=C:\xampp\php\php.exe"
if not defined PHP_EXE for /f "delims=" %%P in ('where php 2^>nul') do if not defined PHP_EXE set "PHP_EXE=%%P"

if not defined PHP_EXE (
  echo [ERROR] PHP tidak ditemukan.
  echo Pastikan XAMPP terpasang di C:\xampp atau tambahkan PHP ke PATH.
  pause
  exit /b 1
)

echo [INFO] PHP: %PHP_EXE%
"%PHP_EXE%" -v
if errorlevel 1 (
  echo [ERROR] PHP tidak dapat dijalankan.
  pause
  exit /b 1
)

if not exist .env copy /y .env.example .env >nul

if exist "C:\xampp\mysql\bin\mysql.exe" (
  echo [INFO] Mengimpor database dasar...
  "C:\xampp\mysql\bin\mysql.exe" -u root -e "CREATE DATABASE IF NOT EXISTS uncp_library CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;"
  "C:\xampp\mysql\bin\mysql.exe" -u root uncp_library < database\database.sql
  echo [INFO] Menjalankan migrasi penyempurnaan...
  "C:\xampp\mysql\bin\mysql.exe" -u root uncp_library < database\migrate_requirements.sql
) else (
  echo [WARN] mysql.exe XAMPP tidak ditemukan.
  echo Import database\database.sql lalu database\migrate_requirements.sql melalui phpMyAdmin.
)

echo [INFO] Menjalankan seed data...
"%PHP_EXE%" tools\seed.php
if errorlevel 1 (
  echo [ERROR] Seed gagal. Periksa pesan di atas.
  pause
  exit /b 1
)

echo [INFO] Memeriksa sistem...
"%PHP_EXE%" tools\check-system.php

echo.
echo [SELESAI] Setup selesai.
echo Jalankan start.bat untuk menjalankan server.
pause
