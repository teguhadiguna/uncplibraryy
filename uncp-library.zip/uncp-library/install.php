<?php
$root=__DIR__;if(!file_exists($root.'/.env'))copy($root.'/.env.example',$root.'/.env');foreach(['storage/logs','storage/cache','storage/backups','uploads/books','uploads/repository','uploads/profile'] as $d)if(!is_dir($root.'/'.$d))mkdir($root.'/'.$d,0775,true);echo "Konfigurasi dasar dibuat. Berikutnya import database/database.sql lalu jalankan: php tools/seed.php\n";
