@echo off
cd /d %~dp0
set /p FILE=Masukkan path file SQL backup: 
php -r "$f=$argv[1]; require 'app/core/bootstrap.php'; $sql=file_get_contents($f); $pdo->exec($sql); echo 'Restore selesai'.PHP_EOL;" "%FILE%"
pause
