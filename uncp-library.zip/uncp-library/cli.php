<?php require __DIR__.'/tools/cli.php';
