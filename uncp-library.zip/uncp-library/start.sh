#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
php -S localhost:8000
