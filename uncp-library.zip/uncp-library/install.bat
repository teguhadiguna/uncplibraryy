@echo off
cd /d %~dp0
php -v >nul 2>&1 || (echo PHP tidak ditemukan di PATH. Pasang XAMPP/PHP terlebih dahulu.& pause & exit /b 1)
if not exist .env copy .env.example .env >nul
php install.php
php tools/check-system.php
pause
