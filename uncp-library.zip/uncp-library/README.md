# UNCP Library Repository
Sistem Repository & Informasi Perpustakaan Universitas Cokroaminoto Palopo. Dibangun dengan PHP 8+, MySQL/MariaDB, HTML/CSS/JavaScript, Chart.js dan arsitektur modular.

## Role dan autentikasi
- Pengguna: registrasi mandiri, katalog buku/skripsi, pengajuan, repository, profil, dan pengaturan.
- Penjaga: katalog, verifikasi buku/skripsi, riwayat verifikasi, profil, dan pengaturan.
- Admin: akun khusus dengan role `admin`/`is_admin=1`, otomatis masuk ke dashboard admin.
- Halaman login tidak meminta pengguna memilih role. Sistem membaca role akun dari database dan mengarahkan ke dashboard yang sesuai.

## Instalasi XAMPP
1. Salin folder ke `C:\xampp\htdocs\uncp-library`.
2. Jalankan Apache dan MySQL dari XAMPP.
3. Buka phpMyAdmin dan import `database/database.sql`.
4. Buka CMD pada folder project.
5. Jalankan `install.bat`.
6. Jalankan `php tools/seed.php`.
7. Buka `http://localhost/uncp-library/`.

## Terminal tanpa Apache
Jalankan:
`php -S localhost:8000`
kemudian buka `http://localhost:8000/`.

## CMD / PowerShell
`install.bat` membuat `.env` dan folder storage.
`start.bat` menjalankan server PHP.
`check-system.bat` memeriksa environment.
`backup.bat` membuat backup SQL.
PowerShell memakai `install.ps1` dan `start.ps1`.

## Linux/macOS
`./install.sh` lalu `./start.sh`.

## CLI
`php cli.php`
Menu tersedia: check system, seed, backup, export, create admin/staff/user, clear cache, system info.

## Akun demo
Admin tersembunyi dari role login publik:
- Login melalui form login biasa
- Username: `admin`
- Password: `Admin@12345`

Penjaga:
- Login melalui form login biasa
- Username: `penjaga`
- Password: `Penjaga@12345`

Pengguna:
- Login melalui form login biasa
- NIM: `20240001`
- Password: `User@12345`

Ganti password default sebelum penggunaan nyata.

## Struktur inti
`app/` konfigurasi dan layanan; `api/` endpoint; `admin/`, `penjaga/`, `pengguna/` UI role; `database/` SQL; `tools/` CLI/seed/backup; `storage/` log/cache/backup; `uploads/` file pengguna.

## Real-time
Dashboard memuat statistik dari API database dan memperbaruinya otomatis setiap 15 detik. Grafik Chart.js dirender dari data API, dengan fallback visual ketika library grafik tidak termuat.

## Catatan
Versi ini adalah fondasi aplikasi yang dapat dijalankan dan dikembangkan. Untuk produksi kampus, tambahkan integrasi SSO kampus, HTTPS, mail provider, object storage, audit policy, backup terjadwal, dan pengujian penetrasi sebelum go-live.

## Setup otomatis dengan CMD
Setelah Apache/MySQL berjalan dari XAMPP:
`setup.bat`
Script akan membuat `.env`, mencoba import database melalui `C:\xampp\mysql\bin\mysql.exe`, menjalankan seed, lalu memeriksa sistem.

## Setup otomatis dengan PowerShell
`./setup.ps1`

## Import database manual via terminal
Windows: `database/import.bat`
Linux/macOS: `./database/import.sh`

## Menjalankan dari XAMPP
Pastikan Apache dan MySQL ON. Lalu buka:
`http://localhost/uncp-library/`

## Menjalankan dari PHP built-in server
Dari CMD/PowerShell:
`cd C:\xampp\htdocs\uncp-library`
`php -S localhost:8000`
Buka `http://localhost:8000/`.

## Perubahan versi penyempurnaan
- Login hanya memiliki dua pilihan: Pengguna dan Admin/Penjaga.
- Admin/Penjaga tidak memiliki registrasi publik; role dibaca dari database.
- Menu peminjaman, pengembalian, denda, dan riwayat peminjaman dihilangkan dari alur aplikasi.
- Pengguna dapat mengajukan buku dan skripsi dengan status Menunggu Verifikasi.
- Admin/Penjaga dapat memproses Disetujui, Ditolak, atau Perlu Perbaikan dan mengirim notifikasi.
- Detail buku/skripsi menyediakan pembaca PDF ketika file digital tersedia.
- Tema dipindahkan ke menu Pengaturan. Logout berada di kiri bawah sidebar.

### Jika database `uncp_library` sudah ada
Jalankan `database/migrate_requirements.sql` satu kali melalui phpMyAdmin, lalu jalankan `tools/seed.php` untuk memastikan akun demo dan data dasar tersedia. `setup.bat` versi ini otomatis menjalankan migrasi tersebut setelah import database.


## Responsive dan adaptive design
Antarmuka menyesuaikan smartphone, tablet, laptop, desktop, dan monitor besar. Pada layar kecil sidebar berubah menjadi drawer, grid/form menyesuaikan kolom, tabel menggunakan scroll horizontal terkontrol, dan PDF viewer mengikuti viewport. Preferensi tema, ukuran teks, kepadatan, animasi, dan sidebar disimpan di browser.

## Perbaikan anti-flash
Preferensi tema dibaca di `<head>` sebelum stylesheet utama agar background tidak kembali putih sesaat ketika berpindah halaman atau saat dark mode dimuat.


## Versi Penyempurnaan Terbaru

Versi ini mempertahankan database dan backend yang sudah ada, dengan penyempurnaan pada:
- landing page yang lebih seimbang dan responsif;
- login tanpa pilihan role dengan pembacaan role otomatis dari database;
- notifikasi flash berbentuk toast floating dan tidak mendorong layout;
- sidebar mobile drawer untuk layar kecil;
- responsive/adaptive layout untuk smartphone, tablet, laptop, desktop, dan monitor besar;
- kontras submenu Pengaturan pada dark mode;
- pengaturan Tampilan berbasis kartu preview;
- perbaikan profil dan penghapusan deklarasi statistik yang tidak valid;
- pengelolaan setting menggunakan session user yang aktif;
- API login mengikuti role otomatis tanpa `role_scope`;
- `run.bat` tambahan untuk menjalankan PHP built-in server di `http://localhost:8000`.

Catatan: database `uncp_library` yang sudah ada tetap digunakan. Jalankan `database/migrate_requirements.sql` satu kali apabila migrasi fitur pengajuan/verifikasi belum pernah diterapkan.


## Catatan Versi Penyempurnaan
- `run.bat` menjalankan PHP built-in server pada `http://localhost:8000/` menggunakan PHP XAMPP.
- Database `uncp_library` yang sudah ada dipertahankan; gunakan `database/migrate_requirements.sql` hanya bila migrasi belum pernah dijalankan.
- Login tidak menampilkan pilihan role; role dibaca otomatis dari database.
- Scroll halaman dan scroll sidebar disimpan per URL selama sesi browser agar navigasi tidak memaksa kembali ke posisi 0.
- Animasi tersedia sebagai Penuh, Ringan, Minimal, dan Nonaktif; default Ringan.
