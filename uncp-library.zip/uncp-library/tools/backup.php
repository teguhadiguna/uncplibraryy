<?php
function backup_database(PDO $pdo): string {
  $dir=dirname(__DIR__).'/storage/backups';if(!is_dir($dir))mkdir($dir,0775,true);$file=$dir.'/uncp_library_'.date('Y-m-d_H-i-s').'.sql';$fh=fopen($file,'w');fwrite($fh,"-- UNCP Library Repository backup\nSET FOREIGN_KEY_CHECKS=0;\n");
  $tables=$pdo->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN);foreach($tables as $table){fwrite($fh,"\nDROP TABLE IF EXISTS `".$table."`;\n");$create=$pdo->query('SHOW CREATE TABLE `'.$table.'`')->fetch();fwrite($fh,$create['Create Table'].";\n");$rows=$pdo->query('SELECT * FROM `'.$table.'`')->fetchAll();foreach($rows as $row){$vals=[];foreach($row as $v)$vals[]=$v===null?'NULL':$pdo->quote($v);fwrite($fh,'INSERT INTO `'.$table.'` VALUES('.implode(',',$vals).');'."\n");}}
fwrite($fh,"SET FOREIGN_KEY_CHECKS=1;\n");fclose($fh);return $file;}
if(PHP_SAPI==='cli'){require __DIR__.'/../app/core/bootstrap.php';try{echo backup_database($pdo)."\n";}catch(Throwable $e){fwrite(STDERR,$e->getMessage()."\n");exit(1);}}
