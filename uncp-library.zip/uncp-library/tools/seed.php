<?php
require __DIR__.'/../app/core/bootstrap.php';
function seed_user(PDO $pdo,string $role,string $name,string $email,string $password,?string $nim=null,?string $username=null,bool $admin=false): int {
  $q=$pdo->prepare('SELECT id FROM roles WHERE name=?'); $q->execute([$role]); $roleId=(int)$q->fetchColumn();
  $q=$pdo->prepare('SELECT id FROM users WHERE email=? LIMIT 1'); $q->execute([$email]); if($id=$q->fetchColumn()){ $up=$pdo->prepare("UPDATE users SET role_id=?,username=?,is_admin=?,status='aktif' WHERE id=?"); $up->execute([$roleId,$username,$admin,$id]); return (int)$id; }
  $st=$pdo->prepare("INSERT INTO users(role_id,nim,username,name,email,password_hash,is_admin,status) VALUES(?,?,?,?,?,?,?,'aktif')");
  $st->execute([$roleId,$nim,$username,$name,$email,password_hash($password,PASSWORD_DEFAULT),$admin]);
  return (int)$pdo->lastInsertId();
}
try {
  $admin=seed_user($pdo,'admin','Administrator UNCP','admin@uncp.local','Admin@12345',null,'admin',true);
  $staff=seed_user($pdo,'penjaga','Penjaga Perpustakaan','penjaga@uncp.local','Penjaga@12345',null,'penjaga',false);
  $user=seed_user($pdo,'pengguna','Mahasiswa Demo','20240001@uncp.local','User@12345','20240001');
  $cats=['Teknologi Informasi','Pemrograman','Basis Data','Jaringan Komputer','Keamanan Siber','Sistem Informasi','Kecerdasan Buatan','Rekayasa Perangkat Lunak','Algoritma','Matematika','Statistika','Bahasa Indonesia','Bahasa Inggris','Manajemen','Ekonomi','Pendidikan','Hukum','Komunikasi','Desain','Karya Ilmiah'];
  $catIds=[]; foreach($cats as $c){$pdo->prepare('INSERT IGNORE INTO book_categories(name) VALUES(?)')->execute([$c]);$q=$pdo->prepare('SELECT id FROM book_categories WHERE name=?');$q->execute([$c]);$catIds[]=(int)$q->fetchColumn();}
  $pubs=['Andi Offset','Informatika','Elex Media Komputindo','Prenada Media','Deepublish'];$pubIds=[];foreach($pubs as $p){$pdo->prepare('INSERT IGNORE INTO publishers(name) VALUES(?)')->execute([$p]);$q=$pdo->prepare('SELECT id FROM publishers WHERE name=?');$q->execute([$p]);$pubIds[]=(int)$q->fetchColumn();}
  $titles=['Dasar-Dasar Pemrograman','Pemrograman Web Modern','Basis Data Terapan','Jaringan Komputer untuk Mahasiswa','Keamanan Komputer','Analisis Sistem Informasi','Pengantar Kecerdasan Buatan','Rekayasa Perangkat Lunak','Algoritma dan Struktur Data','Statistika untuk Informatika','Metodologi Penelitian','UI/UX Design','Administrasi Sistem Linux','Cloud Computing','Machine Learning Praktis','Pemrograman Java','Pemrograman Python','Pemrograman Flutter','Web API Development','Sistem Informasi Perpustakaan'];
  $authors=['Budi Santoso','Andi Wijaya','Siti Rahma','Dedi Kurniawan','Nur Aisyah','Rizal Hidayat'];
  $count=(int)$pdo->query('SELECT COUNT(*) FROM books')->fetchColumn();
  for($i=$count;$i<50;$i++){
    $t=$titles[$i%count($titles)].' Vol. '.(int)(floor($i/count($titles))+1);$isbn='978-623-'.str_pad((string)(100000+$i),6,'0',STR_PAD_LEFT);$stock=1+($i%5);
    $st=$pdo->prepare('INSERT IGNORE INTO books(category_id,publisher_id,isbn,title,author,publication_year,language,pages,shelf_location,description,stock_total,stock_available,status) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)');
    $st->execute([$catIds[$i%count($catIds)],$pubIds[$i%count($pubIds)],$isbn,$t,$authors[$i%count($authors)],2020+($i%7),'Indonesia',120+($i%250),'RAK-'.str_pad((string)(1+($i%10)),2,'0',STR_PAD_LEFT),'Koleksi contoh untuk pengujian UNCP Library Repository.',$stock,$stock,'tersedia']);
  }
  for($i=0;$i<10;$i++) seed_user($pdo,'pengguna','Mahasiswa Demo '.($i+1),'mahasiswa'.($i+1).'@uncp.local','User@12345',(string)(20240002+$i));
  for($i=0;$i<12;$i++){
    $title='Karya Ilmiah Contoh '.($i+1);$q=$pdo->prepare('SELECT COUNT(*) FROM repositories WHERE title=?');$q->execute([$title]);
    if(!$q->fetchColumn()) $pdo->prepare("INSERT INTO repositories(user_id,title,author,nim,study_program,publication_year,type,abstract,keywords,status) VALUES(?,?,?,?,?,?,'skripsi',?,?,?)")->execute([$user,$title,'Mahasiswa Demo','20240001','Teknik Informatika',2024,'Kajian dan contoh abstrak untuk repository kampus.','UNCP, perpustakaan, teknologi','publik']);
  }
  log_activity($pdo,$admin,'admin','Seed database','Data demo dibuat');
  echo "Seed selesai.\nAdmin: admin / Admin@12345\nPenjaga: penjaga / Penjaga@12345\nPengguna: 20240001 / User@12345\n";
} catch(Throwable $e){fwrite(STDERR,'Seed gagal: '.$e->getMessage().'\n');exit(1);}
