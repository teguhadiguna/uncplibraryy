@echo off
cd /d %~dp0
php tools/backup.php
pause
