# Responsive / Adaptive Audit — Final

Breakpoint utama: mobile <= 767px, tablet 768–1199px, laptop/desktop >= 1200px, dengan penyesuaian tambahan <= 430px dan landscape rendah.

- Sidebar: normal desktop, compact tablet, drawer mobile.
- Grid: 4/3/2/1 kolom sesuai ruang.
- Form: 2 kolom desktop/tablet, 1 kolom mobile.
- Tabel: horizontal scroll hanya di `.table-wrap`.
- PDF viewer: lebar 100% dengan tinggi adaptif.
- Profile/settings: layout berubah menjadi satu kolom di mobile.
- Toast: floating dan dibatasi viewport.
- Scroll: body disimpan per URL dengan sessionStorage; posisi scroll sidebar disimpan pada key terpisah agar tetap konsisten saat berpindah halaman.
- Animasi: tidak menggunakan zoom/scale global; default Ringan dan menghormati prefers-reduced-motion.
