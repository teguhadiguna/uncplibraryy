#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
command -v php >/dev/null || { echo 'PHP tidak ditemukan.'; exit 1; }
cp -n .env.example .env || true
php install.php
php tools/check-system.php
