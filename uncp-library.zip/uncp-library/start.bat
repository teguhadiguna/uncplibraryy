@echo off
title Perpustakaan UNCP - Local Server
cd /d "%~dp0"
if not exist "C:\xampp\php\php.exe" (
  echo PHP XAMPP tidak ditemukan di C:\xampp\php\php.exe
  pause
  exit /b 1
)
echo ================================================
echo PERPUSTAKAAN UNCP - PHP DEVELOPMENT SERVER
echo ================================================
echo URL: http://localhost:8000/
echo Jangan tutup jendela ini selama website digunakan.
echo.
"C:\xampp\php\php.exe" -S localhost:8000
pause
