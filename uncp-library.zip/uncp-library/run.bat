@echo off
setlocal EnableExtensions EnableDelayedExpansion

title UNCP Library - Local Network Server

REM ============================================================
REM KONFIGURASI
REM ============================================================

set "PORT=8000"
set "PROJECT_DIR=%~dp0"
set "PHP_EXE=C:\xampp\php\php.exe"

REM Hilangkan tanda \ terakhir
if "%PROJECT_DIR:~-1%"=="\" set "PROJECT_DIR=%PROJECT_DIR:~0,-1%"

cls

echo ============================================================
echo             UNCP LIBRARY LOCAL SERVER
echo ============================================================
echo.

REM ============================================================
REM CEK FOLDER PROJECT
REM ============================================================

if not exist "%PROJECT_DIR%\index.php" (
    echo [ERROR] index.php tidak ditemukan.
    echo.
    echo Pastikan run.bat berada di folder:
    echo %PROJECT_DIR%
    echo.
    pause
    exit /b 1
)

REM ============================================================
REM CEK PHP XAMPP
REM ============================================================

if not exist "%PHP_EXE%" (
    where php >nul 2>&1

    if errorlevel 1 (
        echo [ERROR] PHP tidak ditemukan.
        echo.
        echo Pastikan XAMPP terpasang atau PHP sudah masuk PATH.
        echo.
        pause
        exit /b 1
    ) else (
        set "PHP_EXE=php"
    )
)

echo [OK] Project : %PROJECT_DIR%
echo [OK] PHP     : %PHP_EXE%
echo [OK] Port    : %PORT%
echo.

REM ============================================================
REM CEK PORT 8000
REM ============================================================

netstat -ano | findstr /R /C:":%PORT% .*LISTENING" >nul 2>&1

if not errorlevel 1 (
    echo [INFO] Port %PORT% sedang digunakan.
    echo.
    echo Kemungkinan server sudah berjalan.
    echo.
    goto FIND_IP
)

REM ============================================================
REM CARI IP MOBILE HOTSPOT
REM ============================================================

:FIND_IP

set "HOTSPOT_IP="

REM Prioritas utama: IP default Mobile Hotspot Windows
for /f "usebackq delims=" %%A in (`powershell -NoProfile -ExecutionPolicy Bypass -Command "$x=Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue | Where-Object {$_.IPAddress -like '192.168.137.*'} | Select-Object -First 1 -ExpandProperty IPAddress; if($x){$x}"`) do (
    set "HOTSPOT_IP=%%A"
)

REM Jika tidak menemukan 192.168.137.x,
REM cari alamat IPv4 dari adapter yang biasanya digunakan hotspot
if not defined HOTSPOT_IP (
    for /f "usebackq delims=" %%A in (`powershell -NoProfile -ExecutionPolicy Bypass -Command "$x=Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue | Where-Object {$_.IPAddress -notlike '127.*' -and $_.IPAddress -notlike '169.254.*' -and $_.InterfaceAlias -match 'Local Area Connection|Mobile Hotspot|Wi-Fi Direct|vEthernet'} | Select-Object -First 1 -ExpandProperty IPAddress; if($x){$x}"`) do (
        set "HOTSPOT_IP=%%A"
    )
)

REM ============================================================
REM TAMPILKAN INFORMASI IP
REM ============================================================

echo.
echo ============================================================
echo                 INFORMASI JARINGAN
echo ============================================================
echo.

if defined HOTSPOT_IP (
    echo [OK] IP Hotspot Laptop : !HOTSPOT_IP!
) else (
    echo [PERINGATAN] IP Mobile Hotspot tidak terdeteksi otomatis.
    echo.
    echo Jalankan "ipconfig" untuk melihat IPv4 laptop.
)

echo.
echo URL Laptop :
echo http://localhost:%PORT%/
echo.

if defined HOTSPOT_IP (
    echo URL HP :
    echo http://!HOTSPOT_IP!:%PORT%/
    echo.
)

echo ============================================================
echo.

REM ============================================================
REM JALANKAN PHP SERVER
REM ============================================================

netstat -ano | findstr /R /C:":%PORT% .*LISTENING" >nul 2>&1

if errorlevel 1 (
    echo [INFO] Menjalankan PHP Server...
    echo.
    echo Jangan tutup jendela ini.
    echo.

    start "" "http://localhost:%PORT%/"

    "%PHP_EXE%" -S 0.0.0.0:%PORT% -t "%PROJECT_DIR%"

) else (
    echo [INFO] Server PHP sudah berjalan di port %PORT%.
    echo.

    start "" "http://localhost:%PORT%/"

    echo Tekan tombol apa saja untuk keluar...
    pause >nul
)

endlocal