@echo off
echo Hentikan server PHP yang berjalan dengan Ctrl+C pada jendela server.
pause
