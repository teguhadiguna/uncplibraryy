Write-Host 'Hentikan server PHP dengan Ctrl+C pada terminal server.'
