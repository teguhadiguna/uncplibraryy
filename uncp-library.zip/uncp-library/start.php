<?php echo "UNCP Library Repository\nJalankan server dengan: php -S localhost:8000\n";
