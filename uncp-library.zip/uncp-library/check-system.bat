@echo off
cd /d %~dp0
php tools/check-system.php
pause
