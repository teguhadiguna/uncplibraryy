Set-Location $PSScriptRoot
$php='C:\xampp\php\php.exe'
if(-not (Test-Path $php)){ $cmd=Get-Command php -ErrorAction SilentlyContinue; if($cmd){$php=$cmd.Source} }
if(-not (Test-Path $php)){ Write-Host 'PHP tidak ditemukan. Pastikan XAMPP terpasang atau PHP masuk PATH.'; exit 1 }
if (-not (Test-Path .env)) { Copy-Item .env.example .env }
& $php install.php
Write-Host 'Selanjutnya jalankan setup.ps1 untuk import/migrasi database dan seed data.'
