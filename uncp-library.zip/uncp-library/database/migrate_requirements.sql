USE uncp_library;
SET @db='uncp_library';

SET @sql = IF(NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='books' AND COLUMN_NAME='submitted_by'),
  'ALTER TABLE books ADD COLUMN submitted_by BIGINT NULL AFTER id', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql = IF(NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='books' AND COLUMN_NAME='approval_status'),
  'ALTER TABLE books ADD COLUMN approval_status ENUM(\'disetujui\',\'menunggu\',\'ditolak\',\'perlu_perbaikan\') NOT NULL DEFAULT \'disetujui\' AFTER status', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql = IF(NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='books' AND COLUMN_NAME='rejection_reason'),
  'ALTER TABLE books ADD COLUMN rejection_reason TEXT NULL AFTER approval_status', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql = IF(NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='books' AND COLUMN_NAME='file_path'),
  'ALTER TABLE books ADD COLUMN file_path VARCHAR(255) NULL AFTER rejection_reason', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql = IF(NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='books' AND COLUMN_NAME='submitted_at'),
  'ALTER TABLE books ADD COLUMN submitted_at DATETIME NULL AFTER file_path', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql = IF(NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.STATISTICS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='books' AND INDEX_NAME='idx_books_approval_status'),
  'ALTER TABLE books ADD INDEX idx_books_approval_status(approval_status)', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql = IF(NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE WHERE TABLE_SCHEMA=@db AND TABLE_NAME='books' AND CONSTRAINT_NAME='fk_books_submitter'),
  'ALTER TABLE books ADD CONSTRAINT fk_books_submitter FOREIGN KEY(submitted_by) REFERENCES users(id) ON DELETE SET NULL', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql = IF(NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='repositories' AND COLUMN_NAME='advisor'),
  'ALTER TABLE repositories ADD COLUMN advisor VARCHAR(180) NULL AFTER publication_year', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql = IF(NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='repositories' AND COLUMN_NAME='rejection_reason'),
  'ALTER TABLE repositories ADD COLUMN rejection_reason TEXT NULL AFTER status', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

ALTER TABLE repositories MODIFY COLUMN status ENUM('publik','privat','menunggu','ditolak','perlu_perbaikan') NOT NULL DEFAULT 'menunggu';

CREATE TABLE IF NOT EXISTS submission_history (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT NULL,
  item_type ENUM('buku','skripsi') NOT NULL,
  item_id BIGINT NOT NULL,
  action ENUM('diajukan','disetujui','ditolak','perlu_perbaikan') NOT NULL,
  note TEXT NULL,
  processed_by BIGINT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_submission_item(item_type,item_id),
  INDEX idx_submission_user(user_id),
  CONSTRAINT fk_submission_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL,
  CONSTRAINT fk_submission_processor FOREIGN KEY(processed_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

INSERT IGNORE INTO settings(setting_key,setting_value) VALUES
('library_name','PERPUSTAKAAN UNIVERSITAS COKROAMINOTO PALOPO'),
('theme_default','light');
