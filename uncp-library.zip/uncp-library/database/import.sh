#!/usr/bin/env bash
set -e
cd "$(dirname "$0")/.."
mysql -u root -e "CREATE DATABASE IF NOT EXISTS uncp_library CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;"
mysql -u root uncp_library < database/database.sql
mysql -u root uncp_library < database/migrate_requirements.sql
echo 'Database berhasil diimport dan dimigrasikan.'
