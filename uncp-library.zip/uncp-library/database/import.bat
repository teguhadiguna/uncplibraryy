@echo off
cd /d %~dp0\..
if exist C:\xampp\mysql\bin\mysql.exe (
  C:\xampp\mysql\bin\mysql.exe -u root -e "CREATE DATABASE IF NOT EXISTS uncp_library CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;"
  C:\xampp\mysql\bin\mysql.exe -u root uncp_library < database\database.sql
  C:\xampp\mysql\bin\mysql.exe -u root uncp_library < database\migrate_requirements.sql
  echo Database berhasil diimport dan dimigrasikan.
) else echo XAMPP MySQL client tidak ditemukan.
pause
