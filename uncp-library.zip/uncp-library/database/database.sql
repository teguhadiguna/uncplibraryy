CREATE DATABASE IF NOT EXISTS uncp_library CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE uncp_library;

CREATE TABLE IF NOT EXISTS roles (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(30) NOT NULL UNIQUE,
  description VARCHAR(255) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS users (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  role_id INT NOT NULL,
  nim VARCHAR(30) NULL UNIQUE,
  username VARCHAR(80) NULL UNIQUE,
  name VARCHAR(150) NOT NULL,
  email VARCHAR(160) NOT NULL UNIQUE,
  phone VARCHAR(30) NULL,
  class_name VARCHAR(80) NULL,
  study_program VARCHAR(120) NULL,
  faculty VARCHAR(120) NULL,
  semester TINYINT NULL,
  password_hash VARCHAR(255) NOT NULL,
  is_admin TINYINT(1) NOT NULL DEFAULT 0,
  status ENUM('aktif','nonaktif') NOT NULL DEFAULT 'aktif',
  profile_photo VARCHAR(255) NULL,
  last_login_at DATETIME NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_users_role FOREIGN KEY(role_id) REFERENCES roles(id),
  INDEX idx_users_status(status), INDEX idx_users_role(role_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS book_categories (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL UNIQUE,
  description TEXT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS publishers (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(160) NOT NULL UNIQUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS books (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  submitted_by BIGINT NULL,
  category_id INT NULL,
  publisher_id INT NULL,
  isbn VARCHAR(40) NULL UNIQUE,
  title VARCHAR(220) NOT NULL,
  author VARCHAR(180) NOT NULL,
  publication_year YEAR NULL,
  language VARCHAR(60) DEFAULT 'Indonesia',
  pages INT NULL,
  shelf_location VARCHAR(80) NULL,
  description TEXT NULL,
  cover VARCHAR(255) NULL,
  stock_total INT NOT NULL DEFAULT 1,
  stock_available INT NOT NULL DEFAULT 1,
  status ENUM('tersedia','habis','rusak','hilang') NOT NULL DEFAULT 'tersedia',
  approval_status ENUM('disetujui','menunggu','ditolak','perlu_perbaikan') NOT NULL DEFAULT 'disetujui',
  rejection_reason TEXT NULL,
  file_path VARCHAR(255) NULL,
  submitted_at DATETIME NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY(submitted_by) REFERENCES users(id) ON DELETE SET NULL,
  FOREIGN KEY(category_id) REFERENCES book_categories(id) ON DELETE SET NULL,
  FOREIGN KEY(publisher_id) REFERENCES publishers(id) ON DELETE SET NULL,
  INDEX idx_books_title(title), INDEX idx_books_author(author), INDEX idx_books_year(publication_year), INDEX idx_books_approval_status(approval_status)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS repositories (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT NULL,
  title VARCHAR(240) NOT NULL,
  author VARCHAR(180) NOT NULL,
  nim VARCHAR(30) NULL,
  study_program VARCHAR(120) NULL,
  publication_year YEAR NULL,
  advisor VARCHAR(180) NULL,
  type ENUM('skripsi','jurnal','artikel','makalah','modul','buku_digital','karya_ilmiah','dokumen') NOT NULL DEFAULT 'karya_ilmiah',
  abstract TEXT NULL,
  keywords VARCHAR(500) NULL,
  file_path VARCHAR(255) NULL,
  cover VARCHAR(255) NULL,
  status ENUM('publik','privat','menunggu','ditolak','perlu_perbaikan') NOT NULL DEFAULT 'menunggu',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL,
  INDEX idx_repo_status(status), INDEX idx_repo_title(title)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS loans (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT NOT NULL,
  status ENUM('menunggu','disetujui','dipinjam','dikembalikan','terlambat','ditolak','hilang','rusak') NOT NULL DEFAULT 'menunggu',
  loan_date DATE NULL,
  due_date DATE NULL,
  returned_at DATETIME NULL,
  notes VARCHAR(500) NULL,
  approved_by BIGINT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(id),
  FOREIGN KEY(approved_by) REFERENCES users(id) ON DELETE SET NULL,
  INDEX idx_loans_user(user_id), INDEX idx_loans_status(status), INDEX idx_loans_due(due_date)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS loan_items (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  loan_id BIGINT NOT NULL,
  book_id BIGINT NOT NULL,
  qty INT NOT NULL DEFAULT 1,
  FOREIGN KEY(loan_id) REFERENCES loans(id) ON DELETE CASCADE,
  FOREIGN KEY(book_id) REFERENCES books(id),
  UNIQUE KEY uq_loan_book(loan_id, book_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS returns (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  loan_id BIGINT NOT NULL,
  processed_by BIGINT NOT NULL,
  returned_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  condition_status ENUM('baik','rusak','hilang') NOT NULL DEFAULT 'baik',
  fine_amount DECIMAL(12,2) NOT NULL DEFAULT 0,
  notes VARCHAR(500) NULL,
  FOREIGN KEY(loan_id) REFERENCES loans(id),
  FOREIGN KEY(processed_by) REFERENCES users(id),
  INDEX idx_returns_date(returned_at)
) ENGINE=InnoDB;


CREATE TABLE IF NOT EXISTS submission_history (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT NULL,
  item_type ENUM('buku','skripsi') NOT NULL,
  item_id BIGINT NOT NULL,
  action ENUM('diajukan','disetujui','ditolak','perlu_perbaikan') NOT NULL,
  note TEXT NULL,
  processed_by BIGINT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_submission_item(item_type,item_id),
  INDEX idx_submission_user(user_id),
  CONSTRAINT fk_submission_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL,
  CONSTRAINT fk_submission_processor FOREIGN KEY(processed_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS fines (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  loan_id BIGINT NOT NULL,
  user_id BIGINT NOT NULL,
  amount DECIMAL(12,2) NOT NULL DEFAULT 0,
  reason VARCHAR(255) NOT NULL,
  status ENUM('belum_lunas','lunas') DEFAULT 'belum_lunas',
  paid_at DATETIME NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(loan_id) REFERENCES loans(id),
  FOREIGN KEY(user_id) REFERENCES users(id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS notifications (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT NOT NULL,
  title VARCHAR(180) NOT NULL,
  message TEXT NOT NULL,
  is_read TINYINT(1) DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_notifications_user(user_id, is_read)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS activity_logs (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT NULL,
  role_name VARCHAR(30) NULL,
  action VARCHAR(160) NOT NULL,
  description TEXT NULL,
  ip_address VARCHAR(64) NULL,
  user_agent VARCHAR(500) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL,
  INDEX idx_activity_created(created_at), INDEX idx_activity_user(user_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS settings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  setting_key VARCHAR(120) NOT NULL UNIQUE,
  setting_value TEXT NULL,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

INSERT IGNORE INTO roles(name,description) VALUES
('pengguna','Mahasiswa pengguna perpustakaan'),('penjaga','Penjaga perpustakaan'),('admin','Administrator sistem');

INSERT IGNORE INTO settings(setting_key,setting_value) VALUES
('library_name','UNCP Library Repository'),('return_days','7'),('fine_per_day','1000'),('max_books_per_user','3');
