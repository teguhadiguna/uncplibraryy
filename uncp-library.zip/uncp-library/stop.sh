#!/usr/bin/env bash
echo 'Hentikan server PHP dengan Ctrl+C pada terminal server.'
